Copyright 1997.1998. Nobuki Nakatuji. All right reserved.

This source code is free for commercial and non-commercial
under the following conditions.

1. You must distribute your modified source code for free.
2. When anyone use your modified source code, 
   You must permit to use for free.

Nobuki Nakatuji ( bd1011@hotmail.com )
